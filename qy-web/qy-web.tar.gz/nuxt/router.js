import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0d5173fa = () => interopDefault(import('../pages/404.vue' /* webpackChunkName: "pages/404" */))
const _0072600a = () => interopDefault(import('../pages/category/_name/index.vue' /* webpackChunkName: "pages/category/_name/index" */))
const _0052b29e = () => interopDefault(import('../pages/go/_name.vue' /* webpackChunkName: "pages/go/_name" */))
const _09270de8 = () => interopDefault(import('../pages/page/_id.vue' /* webpackChunkName: "pages/page/_id" */))
const _15f2caba = () => interopDefault(import('../pages/tag/_name/index.vue' /* webpackChunkName: "pages/tag/_name/index" */))
const _2a92939c = () => interopDefault(import('../pages/category/_name/page/_id.vue' /* webpackChunkName: "pages/category/_name/page/_id" */))
const _15b60d82 = () => interopDefault(import('../pages/tag/_name/page/_id.vue' /* webpackChunkName: "pages/tag/_name/page/_id" */))
const _227a1414 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))
const _7493daa8 = () => interopDefault(import('../pages/_name.vue' /* webpackChunkName: "pages/_name" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/404",
    component: _0d5173fa,
    name: "404"
  }, {
    path: "/category/:name?",
    component: _0072600a,
    name: "category-name"
  }, {
    path: "/go/:name?",
    component: _0052b29e,
    name: "go-name"
  }, {
    path: "/page/:id?",
    component: _09270de8,
    name: "page-id"
  }, {
    path: "/tag/:name?",
    component: _15f2caba,
    name: "tag-name"
  }, {
    path: "/category/:name?/page/:id?",
    component: _2a92939c,
    name: "category-name-page-id"
  }, {
    path: "/tag/:name?/page/:id?",
    component: _15b60d82,
    name: "tag-name-page-id"
  }, {
    path: "/",
    component: _227a1414,
    name: "index"
  }, {
    path: "/:name",
    component: _7493daa8,
    name: "name"
  }, {
    path: "*",
    component: _0d5173fa,
    name: "custom"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
